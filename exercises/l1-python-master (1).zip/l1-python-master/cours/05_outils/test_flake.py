import math  # module pas utilisé


def maFonction():
    pass


def maFonction():  # fonction définie deux fois
    return 1


3+4*2  # instruction sans effet: pas détectée
z = 2  # variable inutilisée: pas détectée


x = 3
y = 10
while (x < y):
    x += 1

if (x == y/2):
    break  # break pas dans une structure de boucle
