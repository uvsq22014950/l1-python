def monPrint(a: int, b: int):
    print(a + b)


monPrint(5, 7)
monPrint("salut", "hello")
